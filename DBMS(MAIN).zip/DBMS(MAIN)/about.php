<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us</title>
    <style>
         @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

*{
    font-family: 'Poppins', sans-serif;
    margin:0; 
    padding:0;
    box-sizing: border-box;
    outline: none; 
    border:none;
    text-decoration: none;
    text-transform: capitalize;
}

body {
    background-image: url(./backdoc3.jpg);
    background-size: cover;
    margin: 0;
    padding: 0;
}

.page{
    overflow: hidden;
}

.heading h1{
    color: rgb(5, 52, 85);
    font-size: 55px;
    text-align: center;
    margin-top: 35px;
}

.container{
    display: flex;
    justify-content: center;
    align-items: center;
    width:90%;
    margin: 65px auto;
}

.page_container{
    flex: 1;
    width: 600px;
    margin: 0px 25px;
    animation: fadeInUp 0.5s ease;
}

.page_container h2{
    font-size: 38px;
    margin-bottom: 20px;
    color: #333;
    text-align: center;
}

.page_container .cta-button{
    display: inline-block;
    background-color: rgb(0, 150, 255);
    color: #fff;
    padding: 12px 24px;
    border-radius: 25px;
    font-size: 20px;
    border: none;
    cursor: pointer;
    transition: 0.3s ease;
}

.page_container button:hover{
    background-color: rgb(0, 150, 255);
    transform: scale(1.1);
}

.page_container p{
    font-size: 15px;
    line-height: 1.5;
    margin-bottom: 40px;
}

.images{
    flex:1;
    width: 600px;
    margin: auto;
    animation: fadeInRight 0.5s ease;
}

img{
    width: 100%;
    height: auto;
    border-radius: 10px;
}

@media screen and (max-width: 768px){
    .heading h1{
        font-size: 45px;
        margin-top: 30px;
    }
    .page{
        margin: 0px;
    }
    .container{
        width: 100%;
        flex-direction: column;
        margin: 0px;
        padding: 0 40px;
    }
    .page_container{
        width: 100%;
        margin: 35px 0;
    }
    .page_container h2{
        font-size: 30px;
    }
    .page_container p{
        font-size: 18px;
        margin-bottom: 20px;
    }
    .page_container button{
        font-size: 16px;
        padding: 8px 16px;
    }
    .images{
        width: 100%;
    }
}

@keyframes fadeInUp{
    0%{
        opacity: 0;
        transform: translateY(50px);
    }
    100%{
        opacity: 0;
        transform: translateY(0px);
    }
}

@keyframes fadeInRight{
    0%{
        opacity: 1;
        transform: translateX(-50px);
    }
    100%{
        opacity: 1;
        transform: translateX(0px);
    }
}
    </style>
</head>
<body>
    <section class="page">
        <div class="heading">
        <h1>ABOUT US</h1>
        </div>
        
        <div class="container">
            <div class="page_container">
                <h2>Welcome, to our website....</h2>
                <p>In this endeavour to provide better holistic healthcare services, we have opened a new modern. 
                    This new website is equipped with latest high end features and cutting edge services, 
                    dedicated and well trained human resources to provide satisfying healthcare experience. 
                    To achieve this objective, we have developed several features of Excellence in their respective specialties.
                    With an excellent Emergency Medicine team providing efficient care 24 hours a day, 365 days a year. 
                    As per infrastructure is on par with global standards with 75 bedded ICUs and manned by trained critical care team 24 x 7.
                    our website will help you to get started on your journey to good health.  
                </p>
                <!-- <button class="cta-button">Learn More</button> -->
            </div>
            <div class="images">
                <div id="imageSlider" class="slider">
                    <img class="slide" src="./d1.jpg" alt="Doctor 1">
                    <img class="slide" src="./d2.jpg" alt="Doctor 2">
                    <img class="slide" src="./d3.jpg" alt="Doctor 3">
                    <img class="slide" src="./d4.jpg" alt="Doctor 4">
                    <img class="slide" src="./d5.jpg" alt="Doctor 5">
                    <img class="slide" src="./d6.jpg" alt="Doctor 6">
                </div>
            </div>
        </div>

        <script>
            // JavaScript code for image slider
            let currentSlide = 0;

            function showSlide(index) {
                const slides = document.getElementsByClassName('slide');
                if (index < 0) {
                    currentSlide = slides.length - 1;
                } else if (index >= slides.length) {
                    currentSlide = 0;
                } else {
                    currentSlide = index;
                }

                for (let i = 0; i < slides.length; i++) {
                    slides[i].style.display = 'none';
                }

                slides[currentSlide].style.display = 'block';
            }

            function nextSlide() {
                showSlide(currentSlide + 1);
            }

            function prevSlide() {
                showSlide(currentSlide - 1);
            }

            // Set an interval to automatically advance the slide
            setInterval(nextSlide, 1000); // Change 5000 to the desired interval in milliseconds
        </script>
    </section>
</body>
</html>