<?php

@include 'config.php';

if(isset($_POST['add_patient'])){

   $patient_name = $_POST['patient_name'];
   $patient_id = $_POST['patient_id'];
   $patient_image = $_FILES['patient_image']['name'];
   $patient_image_tmp_name = $_FILES['patient_image']['tmp_name'];
   $patient_image_folder = 'uploaded_img/'.$patient_image;

   if(empty($patient_name) || empty($patient_id) || empty($patient_image)){
      $message[] = 'please fill out all';
   }else{
      $insert = "INSERT INTO patient(name, id, image) VALUES('$patient_name', '$patient_id', '$patient_image')";
      $upload = mysqli_query($conn,$insert);
      if($upload){
         move_uploaded_file($patient_image_tmp_name, $patient_image_folder);
         $message[] = 'new patient added successfully';
      }else{
         $message[] = 'could not add the patient';
      }
   }

};

if(isset($_GET['delete'])){
   $id = $_GET['delete'];
   mysqli_query($conn, "DELETE FROM patient WHERE id = $id");
   header('location:admin.php');
};

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>admin page</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <!-- <link rel="stylesheet" href="css/admstyle.css"> -->
   <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

:root{
   --green:#27ae60;
   --black:#333;
   --white:#fff;
   --bg-color:#eee;
   --box-shadow:0 .5rem 1rem rgba(0,0,0,.1);
   --border:.1rem solid var(--black);
}

*{
   font-family: 'Poppins', sans-serif;
   margin:0; 
   padding:0;
   box-sizing: border-box;
   outline: none; border:none;
   text-decoration: none;
   text-transform: capitalize;
}

html{
   font-size: 62.5%;
   overflow-x: hidden;
}

.btn{
   display: block;
   width: 100%;
   cursor: pointer;
   border-radius: .5rem;
   margin-top: 1rem;
   font-size: 1.7rem;
   padding:1rem 3rem;
   background: var(--green);
   color:var(--white);
   text-align: center;
}

.btn:hover{
   background: var(--black);
}

.message{
   display: block;
   background: var(--bg-color);
   padding:1.5rem 1rem;
   font-size: 2rem;
   color:var(--black);
   margin-bottom: 2rem;
   text-align: center;
}

.container{
   max-width: 1200px;
   padding:2rem;
   margin:0 auto;
}

.admin-patient-form-container.centered{
   display: flex;
   align-items: center;
   justify-content: center;
   min-height: 100vh;
   
}

.admin-patient-form-container form{
   max-width: 50rem;
   margin:0 auto;
   padding:2rem;
   border-radius: .5rem;
   background: var(--bg-color);
}

.admin-patient-form-container form h3{
   text-transform: uppercase;
   color:var(--black);
   margin-bottom: 1rem;
   text-align: center;
   font-size: 2.5rem;
}

.admin-patient-form-container form .box{
   width: 100%;
   border-radius: .5rem;
   padding:1.2rem 1.5rem;
   font-size: 1.7rem;
   margin:1rem 0;
   background: var(--white);
   text-transform: none;
}

.patient-display{
   margin:2rem 0;
}

.patient-display .patient-display-table{
   width: 100%;
   text-align: center;
}

.patient-display .patient-display-table thead{
   background: var(--bg-color);
}

.patient-display .patient-display-table th{
   padding:1rem;
   font-size: 2rem;
}


.patient-display .patient-display-table td{
   padding:1rem;
   font-size: 2rem;
   border-bottom: var(--border);
}

.patient-display .patient-display-table .btn:first-child{
   margin-top: 0;
}

.patient-display .patient-display-table .btn:last-child{
   background: crimson;
}

.patient-display .patient-display-table .btn:last-child:hover{
   background: var(--black);
}









@media (max-width:991px){

   html{
      font-size: 55%;
   }

}

@media (max-width:768px){

   .product-display{
      overflow-y:scroll;
   }

   .product-display .product-display-table{
      width: 80rem;
   }

}

@media (max-width:450px){

   html{
      font-size: 50%;
   }

}
   </style>

</head>
<body>

<?php

if(isset($message)){
   foreach($message as $message){
      echo '<span class="message">'.$message.'</span>';
   }
}

?>
   
<div class="container">

   <div class="admin-patient-form-container">

      <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
         <h3>add patient</h3>
         <input type="text" placeholder="enter patient name" name="patient_name" class="box">
         <input type="number" placeholder="enter patient_id" name="patient_id" class="box">
         <input type="file" accept="image/png, image/jpeg, image/jpg" name="patient_image" class="box">
         <input type="submit" class="btn" name="add_patient" value="add patient">
      </form>

   </div>

   <?php

   $select = mysqli_query($conn, "SELECT * FROM patient");
   
   ?>
   <div class="patient-display">
      <table class="patient-display-table">
         <thead>
         <tr>
            <th>patient image</th>
            <th>patient name</th>
            <th>patient_id</th>
            <th>action</th>
         </tr>
         </thead>
         <?php while($row = mysqli_fetch_assoc($select)){ ?>
         <tr>
            <td><img src="uploaded_img/<?php echo $row['image']; ?>" height="100" alt=""></td>
            <td><?php echo $row['name']; ?></td>
            <td><?php echo $row['id']; ?></td>
            <td>
               <a href="admin_update.php?edit=<?php echo $row['id']; ?>" class="btn"> <i class="fas fa-edit"></i> edit </a>
               <a href="admin.php?delete=<?php echo $row['id']; ?>" class="btn"> <i class="fas fa-trash"></i> delete </a>
            </td>
         </tr>
      <?php } ?>
      </table>
   </div>

</div>


</body>
</html>    admin.php lo save chey