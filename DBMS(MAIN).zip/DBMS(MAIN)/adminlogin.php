<?php 
   session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
     <link rel="stylesheet" href="siri.css">
    <link rel="icon" sizes="any" mask="" href="./stethoscope-solid.svg" style="color: #1c5fd4;">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <title>Admin Login</title>
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600&display=swap');

*{
    margin: 0;
    padding: 0;
    box-sizing:border-box;
    font-family: 'Poppins', sans-serif;
}

body{
    display: flex;
    justify-content:center;
    align-items: center;
    min-height: 100vh;
    background:url(./backdoc3.jpg); 
    background-size: cover;
    background-position: center;
    padding: 20px;
}

.wrapper{
    width: 420px;
    background:transparent;
    border: 2px solid rgba(255,255,255,.2);
    backdrop-filter: blur(5px);
    color: black;
    border-radius: 35px;
    padding: 30px 40px;
    margin: 0 auto;
    
}

.wrapper h1{
    font-size: 36px;
    text-align: center;
}

.wrapper .input-box{
    position: relative;
    width: 100%;
    height: 50px;
    margin: 30px 0;
}

.input-box input{
    width: 100%;
    height: 100%;
    background: transparent;
    border: none;
    outline: none;
    border: 2px solid black;
    border-radius: 40px;
    font-size:16px;
    color:black;
    padding: 20px 45px 20px 20px;
}

.input-box input::placeholder{
    color:black;
}

.input-box i{
    position:absolute;
    right: 20px;
    top:50%;
    transform: translateY(-50%);
    font-size: 20px;
}

.input-box img{
    position:absolute;
    right: 20px;
    top:50%;
    transform: translateY(-50%);
    font-size: 20px;
}

.wrapper .remember-forget{
    display: flex;
    justify-content:space-between;
    font-size: 14.5px;
    margin:-15px 0 15px;
}

.remember-forget label input{
    accent-color: black;
    margin-right: 3px;
}

.remember-forget a{
    color: black;
    text-decoration: none;
}

.remember-forget a:hover{
    text-decoration: underline;
}

.wrapper .btn{
    width: 100%;
    height: 45px;
    background: #000;
    border: none;
    outline: none;
    border-radius: 40px;
    box-shadow: 0 0 25px rgba(0,0,0,.2);
    cursor: pointer;
    font-size: 16px;
    color: #fff;
    font-weight:600;
}

.sub .btn{
    width: 100%;
    height: 45px;
    background: rgb(107, 203, 241);
    border: none;
    outline: none;
    border-radius: 40px;
    box-shadow: 0 0 10px rgba(0,0,0,.1);
    cursor: pointer;
    font-size: 16px;
    color: black;
    font-weight:600;
}

.wrapper .register-link{
    font-size: 14.5px;
    text-align: center;
    margin: 20px 0px 15px;
}

.register-link p a{
    color:black;
    text-decoration: none;
    font-weight: 600;
}

.register-link p a:hover{
    text-decoration: underline;
}

.container{
    position: relative;
    max-width: 700px;
    width: 100%;
    background: transparent;
    backdrop-filter: blur(55px);
    padding: 25px;
    border-radius: 45px;
    box-shadow: 0 0 15px rgba(0,0,0,0.2);
}

.container header{
    font-size: 1.5rem;
    color: black;
    font-weight: 500;
    text-align: center;
    padding: 25px;
}

.conatiner .form{
    margin-top: 30px;
}

.form .inputbox{
    width: 100%;
    margin-top: 20px;
}

.inputbox label{
    color: black;
}

.form :where(.inputbox input, .select-box){
    position: relative;
    height: 50px;
    width: 100%;
    outline:none;
    border: 1px solid black;
    border-radius: 10px;
    padding: 0 15px;
    font-size: 1rem;
    color: black;
    margin-top: 8px;
}

.inputbox input:focus{
    box-shadow: 0 1px 0 rgba(0,0,0,.1);
}

.form .column{
    display: flex;
    column-gap: 15px;
}

.form .gender-box{
    margin-top: 20px;
}

.gender-box h3{
    color: black;
    font-size: 1rem;
    font-weight: 400;
    margin-bottom: 8px;
}

.form .gender-option{
    display: flex;
    column-gap: 15px;
}

.form :where(.gender-option, .gender){
    display: flex;
    align-items: center;
    column-gap: 40px;
    flex-wrap: wrap;
}

.form .gender{
    column-gap: 5px;
    cursor: pointer;
} 

.gender input{
    accent-color: skyblue;

}

.gender label{
    color: black;
}

.form :where(.gender input, .gender label){
    cursor: pointer;
}

.select-box select{
    height: 100%;
    width: 100%;
    outline: none;
    border: none;
    color: black;
    font-size: 1rem;
    
}

.address :where(input, .select-box){
    margin-top: 15px;
}

.form button{
    height: 55px;
    width: 100%;
    background-color: transparent;
    border-radius: 6px;
    color: black;
    font-size: 1rem;
    font-weight: 400;
    border: none;
    margin-top: 30px;
    cursor: pointer;
}

.form button:hover{
    background-color:#000;
    transition: all 0.2s ease;
}

@media screen and (max-width: 500px) {
    .form .column{
        flex-wrap: wrap;
    }
    .form :where(.gender-option, .gender) {
        row-gap: 15px;
    }
    
}
.or{
    margin-left: 150px;
}
.gicon{
    height: 15px;
    width: 15px;
    margin-left: 120px;
}
.msoft{
    height: 25px;
    width: 25px;
    margin-left: 180px;
}
.fb{
    height: 35px;
    width: 35px;
    margin-left: 130px;
    margin-top: 15px;
}
.images img{
    /* margin-left: 50px; */
    height: 25px;
    width: 25px;
}
.hr{
    border: 0;
    height: 1px;
    background: #c2c2cc;
    margin-left: 5px;

}.hr span{
    display: block;
    width: 20px;
    margin: auto;
    background: #fff;
    font-size: 14px;
    margin-top: -12px;
    
    
}
.image-button {
    display: inline-block;
    height: 10px;
    width: 10px;
    color: #fff;
    text-decoration: none;
    border-radius: 5px;
    transition: background-color 0.3s ease;
}
.input-box img{
   position: absolute;
}
.sub {
    width: 100%;
    height: 45px;
    background: black;
    border: none;
    outline: none;
    border-radius: 40px;
    box-shadow: 0 0 10px #fff;
    cursor: pointer;
    font-size: 16px;
    color: #fff;
    font-weight:600;
    position: relative;
}
.image-button:hover {
    background-color:transparent;
}
.container p{
    font-size: 30px;
    text-align: center;
}

#toggle{
    position: absolute;
    top: 50%;
    transform: translateY(-50%);
    right: 20px;
    background: url(show-alt-regular-24.png);
    background-size: cover;
    width: 30px;
    height: 30px;
    cursor: pointer;

}

#toggle.hide{
    background: url(./eye-solid\ \(1\).svg);
    background-size: cover;
} 
</style>
</head>
<body>
    <!-- <div class="container">  
         <div class="box form-box">  -->
            <?php 
            include("configure.php");
              if(isset($_POST['submit']))
              {
                $admin_name = mysqli_real_escape_string($con,$_POST['admin_name']);
                $pin = mysqli_real_escape_string($con,$_POST['pin']);

                $result = mysqli_query($con,"SELECT * FROM admin WHERE admin_name='$admin_name' AND pin='$pin' ") or die("Select Error");
                $row = mysqli_fetch_assoc($result);

                if(is_array($row) && !empty($row)){
                    $_SESSION['valid'] = $row['admin_name'];
                    // $_SESSION['name'] = $row['name'];
                    // $_SESSION['age'] = $row['age'];
                    $_SESSION['pin'] = $row['pin'];
                    // $_SESSION['mobile'] = $row['mobile'];
                    // $_SESSION['state'] = $row['state'];
                    // $_SESSION['country'] = $row['country'];
                    // $_SESSION['date'] = $row['date'];
                    // $_SESSION['id'] = $row['id'];
                }
                else{
                    echo "<div class='container'>
                       <p>Wrong Admin name or pin Please try again</p>
                       <br>";
                    echo "
                        <br><a href='adminlogin.php'><button class='sub'>Go Back To Login Page </button>
                        </div>";
                    exit;
                }
                if(isset($_SESSION['valid'])){
                    include("admin.php");
                }
                }else{

            
            ?>
      <script>
                document.addEventListener('DOMContentLoaded', function () 
                {
                    let eyeIcon = document.getElementById("eyeicon");
                    let passwordInput = document.getElementById("pin");
            
                    eyeIcon.addEventListener('click', function () {
                        if (passwordInput.type === "password") 
                        {
                            passwordInput.type = "text";
                        } 
                        else 
                        {
                            passwordInput.type = "password";
                        }
                    });
                });
      </script>
      
        <div class="wrapper">
            <h1>ADMIN LOGIN</h1>
            <form action="" method="post">
            <div class="input-box">
                <input type="text" id="admin_name" name="admin_name" placeholder="Enter admin name" required>
                <i class='bx bx-envelope'></i>
            </div>
            <div class="input-box">
                <input type="password" id="pin" name="pin" placeholder="Enter admin pin" required>
                <img src="./eye-solid (1).svg" id="eyeicon"/>
            </div>
            <input type="submit" class="btn" name="submit" value="Login" required>
           <br><br>
            <div class="hr">
                <hr horizontal line >
                <span> OR </span>
            </div>
            <div class="images">
                <a href="https://accounts.google.com/InteractiveLogin/signinchooser?elo=1&ifkv=ASKXGp05NySkgPKLjLNCQ6r9Yeum24krQTZf2Xo7-ZoeqahF-M_6e6kkMP-nV2AdleN0T65GpRQc_A&theme=glif&flowName=GlifWebSignIn&flowEntry=ServiceLogin" class="image-button">
                    <img src="google icon.jpg" alt="Button Image" class="gicon">
                </a>
                <a href="https://example.com" class="image-button">
                    <img src="./twitter.png" alt="Button Image" class="msoft">
                </a>
                <a href="https://example.com" class="image-button">
                    <img src="./fb-1.png" alt="Button Image" class="fb">
                </a>
            </div>
            </form>
        </div>  
      </div>  
    </div>  
<?php } ?>
</body>
</html>