<?php

@include 'configure.php';

if(isset($_POST['add_ambulance'])){

   $patient_name = $_POST['patient_name'];
   $patient_id = $_POST['patient_id'];
   $payment_image = $_FILES['payment_image']['name'];
   $payment_image_tmp_name = $_FILES['payment_image']['tmp_name'];
   $payment_image_folder = 'images/'.$payment_image;
   $patient_gender = $_POST['patient_gender'];
   $payment_status = $_POST['payment_status'];
   $driver_name = $_POST['driver_name'];
   $location = $_POST['location'];
   $time = $_POST['time'];
   $phno = $_POST['phno'];

   if(empty($patient_name) || empty($patient_id) || empty($payment_image) || empty($patient_gender) || empty($payment_status) || empty($driver_name) || empty($location) || empty($time) || empty($phno) ){
      $message[] = 'please fill out all';
   }else{
      $insert = "INSERT INTO ambulance(patient_name, patient_id, image, patient_gender, payment_status, dname, location, time, phno) VALUES('$patient_name', '$patient_id', '$payment_image', '$patient_gender', '$payment_status', '$driver_name', '$location', '$time', '$phno')";
      $upload = mysqli_query($con,$insert);
      if($upload){
         move_uploaded_file($payment_image_tmp_name,$payment_image_folder);
         $message[] = 'new ambulance details added successfully';
      }else{
         $message[] = 'could not add the ambulance details';
      }
   }

};

if(isset($_GET['delete'])){
   $id = $_GET['delete'];
   mysqli_query($con, "DELETE FROM ambulance WHERE patient_id = $id");
   header('location:ambulance.php');
};

?>


<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>Ambulance booking</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

   <!-- custom css file link  -->
   <!-- <link rel="stylesheet" href="css/admstyle.css"> -->
   <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

:root{
   --green:#27ae60;
   --black:#333;
   --white:#fff;
   --bg-color:#eee;
   --box-shadow:0 .5rem 1rem rgba(0,0,0,.1);
   --border:.1rem solid var(--black);
}

*{
   font-family: 'Poppins', sans-serif;
   margin:0; 
   padding:0;
   box-sizing: border-box;
   outline: none; border:none;
   text-decoration: none;
   text-transform: capitalize;
   /* background: url(https://t3.ftcdn.net/jpg/04/26/35/20/360_F_426352043_A3mpOXheHHeSO7HLTiQ8ePSLyk0GD8jE.jpg); */
}

html{
   font-size: 62.5%;
   overflow-x: hidden;
}

/* body{
   background: url(https://t3.ftcdn.net/jpg/04/26/35/20/360_F_426352043_A3mpOXheHHeSO7HLTiQ8ePSLyk0GD8jE.jpg);
} */

.btn{
   display: block;
   width: 100%;
   cursor: pointer;
   border-radius: .5rem;
   margin-top: 1rem;
   font-size: 1.7rem;
   padding:1rem 3rem;
   background: rgb(0, 150, 255);
   color:var(--white);
   text-align: center;
}

.btn:hover{
   background: var(--black);
}

.message{
   display: block;
   background: rgb(0, 150, 255);
   padding:1.5rem 1rem;
   font-size: 2rem;
   color:var(--black);
   margin-bottom: 2rem;
   text-align: center;
}

.container{
   max-width: 1200px;
   padding:2rem;
   margin:0 auto;
}

.admin-ambulance-form-container.centered{
   display: flex;
   align-items: center;
   justify-content: center;
   min-height: 100vh;
}

.admin-ambulance-form-container form{
   max-width: 50rem;
   margin:0 auto;
   padding:2rem;
   border-radius: .5rem;
   background: var(--bg-color);
}

.admin-ambulance-form-container form h3{
   text-transform: uppercase;
   color:var(--black);
   margin-bottom: 1rem;
   text-align: center;
   font-size: 2.5rem;
}

.admin-ambulance-form-container form .box{
   width: 100%;
   border-radius: .5rem;
   padding:1.2rem 1.5rem;
   font-size: 1.7rem;
   margin:1rem 0;
   background: var(--white);
   text-transform: none;
}

.ambulance-display{
   margin:2rem 0;
}

.ambulance-display .ambulance-display-table{
   width: 100%;
   text-align: center;
}

.ambulance-display .ambulance-display-table thead{
   background: var(--bg-color);
}

.ambulancce-display .ambulance-display-table th{
   padding:1rem;
   font-size: 2rem;
}


.ambulance-display .ambulance-display-table td{
   padding:1rem;
   font-size: 2rem;
   border-bottom: var(--border);
}

.ambulance-display .ambulance-display-table .btn:first-child{
   margin-top: 0;
}

.ambulance-display .ambulance-display-table .btn:last-child{
   background: crimson;
}

.ambulance-display .ambulance-display-table .btn:last-child:hover{
   background: var(--black);
}










@media (max-width:991px){

   html{
      font-size: 55%;
   }

}

@media (max-width:768px){

   .ambulance-display{
      overflow-y:scroll;
   }

   .ambulance-display .ambulance-display-table{
      width: 80rem;
   }

}

@media (max-width:450px){

   html{
      font-size: 50%;
   }

}
   </style>

</head>
<body class="bd">

<?php

if(isset($message)){
   foreach($message as $message){
      echo '<span class="message">'.$message.'</span>';
   }
}

?>
   
<div class="container">

   <div class="admin-ambulance-form-container">

      <form action="<?php $_SERVER['PHP_SELF'] ?>" method="post" enctype="multipart/form-data">
         <h3>add ambulance</h3>
         <input type="text" placeholder="Enter patient name" name="patient_name" class="box" required>
         <input type="number" placeholder="Enter patient_id" name="patient_id" class="box"  required>
         <input type="file" accept="image/png, image/jpeg, image/jpg" name="payment_image" class="box" required>
         <input type="text" placeholder="Enter patient gender" name="patient_gender" class="box" required>
         <input type="text" placeholder="Payment status (Done/Not)" name="payment_status" class="box" required>
         <input type="text" placeholder="Enter driver name" name="driver_name" class="box" required>
         <input type="text" placeholder="Enter location" name="location" class="box" required>
         <input type="text" placeholder="Enter time" name="time" class="box" required>
         <input type="text" placeholder="Enter the phno " name="phno"class="box" required>
         <input type="submit" class="btn" name="add_ambulance" value="add ambulance">
      </form>

   </div>

   <?php

   $select = mysqli_query($con, "SELECT * FROM ambulance");
   
   ?>
   <div class="ambulance-display">
      <table class="ambulance-display-table">
         <thead>
         <tr>
            <th>ambulance image</th>
            <th>patient name</th>
            <th>patient_id</th>
            <th>patient_gender</th>
            <th>payment_status</th>
            <th>driver_name</th>
            <th>location</th>
            <th>time</th>
            <th>phno</th>
            <th>action</th>
            
         </tr>
         </thead>
         <?php while($row = mysqli_fetch_assoc($select)){ ?>
         <tr>
            <td><img src="images/<?php echo $row['image']; ?>" height="100" alt=""></td>
            <td><?php echo $row['patient_name']; ?></td>
            <td><?php echo $row['patient_id']; ?></td>
            <td><?php echo $row['patient_gender']; ?></td>
            <td><?php echo $row['payment_status']; ?></td>
            <td><?php echo $row['dname']; ?></td>
            <td><?php echo $row['location']; ?></td>
            <td><?php echo $row['time']; ?></td>
            <td><?php echo $row['phno']; ?></td>
            <td>
               <a href="ambulance_update.php?edit=<?php echo $row['patient_id']; ?>" class="btn"> <i class="fas fa-edit"></i> Edit </a>
               <a href="ambulance.php?delete=<?php echo $row['patient_id']; ?>" class="btn"> <i class="fas fa-trash"></i> Delete </a>
            </td>
         </tr>
      <?php } ?>
      </table>
   </div>
</div>
</body>
</html>