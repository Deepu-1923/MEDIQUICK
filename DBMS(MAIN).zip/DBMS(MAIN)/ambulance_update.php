<?php

@include 'configure.php';

$id = $_GET['edit'];

if(isset($_POST['update_ambulance'])){

   $patient_name = $_POST['patient_name'];
   $patient_id = $_POST['patient_id'];
   $payment_image = $_FILES['payment_image']['name'];
   $payment_image_tmp_name = $_FILES['payment_image']['tmp_name'];
   $payment_image_folder = 'images/'.$payment_image;
   $phno = $_POST['phno'];

   if(empty($patient_name) || empty($patient_id) || empty($payment_image) || empty($phno))
   {
      $message[] = 'please fill out all!';    
   }
   else
   {

      $update_data = "UPDATE ambulance SET name='$patient_name', id='$patient_id', image='$payment_image', phno='$phno'  WHERE id = '$id'";
      $upload = mysqli_query($con, $update_data);

      if($upload){
         move_uploaded_file($payment_image_tmp_name, $payment_image_folder);
         header('location:ambulance.php');
      }else{
         $$message[] = 'please fill out all!'; 
      }

   }
};

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <!-- <link rel="stylesheet" href="css/admstyle.css"> -->
   <style>
      @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600&display=swap');

:root{
   --green:#27ae60;
   --black:#333;
   --white:#fff;
   --bg-color:#eee;
   --box-shadow:0 .5rem 1rem rgba(0,0,0,.1);
   --border:.1rem solid var(--black);
}

*{
   font-family: 'Poppins', sans-serif;
   margin:0; 
   padding:0;
   box-sizing: border-box;
   outline: none; border:none;
   text-decoration: none;
   text-transform: capitalize;
   /* background: url(https://t3.ftcdn.net/jpg/04/26/35/20/360_F_426352043_A3mpOXheHHeSO7HLTiQ8ePSLyk0GD8jE.jpg); */
}

html{
   font-size: 62.5%;
   overflow-x: hidden;
}

.btn{
   display: block;
   width: 100%;
   cursor: pointer;
   border-radius: .5rem;
   margin-top: 1rem;
   font-size: 1.7rem;
   padding:1rem 3rem;
   background: rgb(0, 150, 255);
   color:var(--white);
   text-align: center;
}

.btn:hover{
   background: var(--black);
}

.message{
   display: block;
   background: var(--bg-color);
   padding:1.5rem 1rem;
   font-size: 2rem;
   color:var(--black);
   margin-bottom: 2rem;
   text-align: center;
}

.container{
   max-width: 1200px;
   padding:2rem;
   margin:0 auto;
}

.admin-ambulance-form-container.centered{
   display: flex;
   align-items: center;
   justify-content: center;
   min-height: 100vh;
   
}

.admin-ambulance-form-container form{
   max-width: 50rem;
   margin:0 auto;
   padding:2rem;
   border-radius: .5rem;
   background: var(--bg-color);
}

.admin-ambulance-form-container form h3{
   text-transform: uppercase;
   color:var(--black);
   margin-bottom: 1rem;
   text-align: center;
   font-size: 2.5rem;
}

.admin-ambulance-form-container form .box{
   width: 100%;
   border-radius: .5rem;
   padding:1.2rem 1.5rem;
   font-size: 1.7rem;
   margin:1rem 0;
   background: var(--white);
   text-transform: none;
}

.ambulance-display{
   margin:2rem 0;
}

.ambulance-display .ambulance-display-table{
   width: 100%;
   text-align: center;
}

.ambulance-display .ambulance-display-table thead{
   background: var(--bg-color);
}

.ambulance-display .ambulance-display-table th{
   padding:1rem;
   font-size: 2rem;
}


.ambulance-display .ambulance-display-table td{
   padding:1rem;
   font-size: 2rem;
   border-bottom: var(--border);
}

.ambulance-display .ambulance-display-table .btn:first-child{
   margin-top: 0;
}

.ambulance-display .ambulance-display-table .btn:last-child{
   background: crimson;
}

.ambulance-display .ambulance-display-table .btn:last-child:hover{
   background: var(--black);
}









@media (max-width:991px){

   html{
      font-size: 55%;
   }

}

@media (max-width:768px){

   .ambulance-display{
      overflow-y:scroll;
   }

   .ambulance-display .ambulance-display-table{
      width: 80rem;
   }

}

@media (max-width:450px){

   html{
      font-size: 50%;
   }

}
   </style>
</head>
<body>

<?php
   if(isset($message)){
      foreach($message as $message){
         echo '<span class="message">'.$message.'</span>';
      }
   }
?>

<div class="container">


<div class="admin-ambulance-form-container centered">

   <?php
      
      $select = mysqli_query($con, "SELECT * FROM ambulance WHERE patient_id = '$id'");
      while($row = mysqli_fetch_assoc($select)){

   ?>
   
   <form action="" method="post" enctype="multipart/form-data">
      <h3 class="title">Booking Update</h3>
      <input type="text" class="box" name="patient_name" value="<?php echo $row['patient_name']; ?>" placeholder="enter the patient name" required>
      <input type="number" min="0" class="box" name="patient_id" value="<?php echo $row['patient_id']; ?>" placeholder="enter the patient id"  required>
      <input type="file" class="box" name="payment_image"  accept="image/png, image/jpeg, image/jpg" required>
      <input type="text" placeholder="enter the phno " name="phno"class="box" required>
      <input type="submit" value="update ambulance" name="update_ambulance" class="btn">
      <a href="ambulance.php" class="btn">go back!</a>
   </form>
   


   <?php }; ?>

   

</div>

</div>

</body>
</html>