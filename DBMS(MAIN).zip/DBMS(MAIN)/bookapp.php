<!DOCTYPE html>
<html lang="en">
    <head>
      <link rel="icon" sizes="any" mask="" href="./stethoscope-solid.svg" style="color: #1c5fd4;">
        <meta charset="UTF=8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="siri.css">
        <title>Book Appointment</title>
       <!-- <img scr="https://pin.it/2f79yuF">  -->

    </head>
  <body>  
    <style>
        body {
            font-family: Arial, sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-image: url(./backdoc3.jpg);

        }
          
.input-box input{
    width: 100%;
    height: 50px;
    background: transparent;
    /* border: none; */
    outline: none;
    border: 2px solid #000;
    margin-top: auto;
    border-radius: 40px;
    font-size:3px;
    color:black;
    padding: 20px 45px 20px 20px;
    color: #000;
    font-size: 1.5rem;
    font-weight: 500;
    text-align: center;
    padding: 25px;
} 
          form {
            width: 70%;
            height: 100%;
            padding: 20px;
            border: 1.5px solid #000;
            border-radius: 35px;
            box-shadow: black;
          }
          input {
            width: 100%;
            height: 50px;
            padding: 8px;
            margin-bottom: 16px;
            box-sizing: border-box;
            /* background-image: url(./eye-icon1.jpg); */
            background-position:right;
            padding-left: 30;
            background-size: 20px;
            background-repeat: no-repeat;
            border-radius: 8px;
            align-content: center;
            background: transparent;
      
          }
          .button  {
            background-color: #1456b8f9;
            color: #fff;
            padding: 10px,15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;

          }

          /* button:hover {
             background-color: #4597a0;
          } */
          .btn{
                background-color: #10c189;
                box-shadow: #000;
          }
          .heading{
            font-size: 70px;
            color: #000;
            border: #000;
          }
          .heading span{
            font-size: 100px;
            color: #000;
            border: #000;
          }
          input,
        select,
        textarea {
            width: 100%;
            padding: 0.5em;
            margin-top: 0.5em;
            box-sizing: border-box;
            border: 1.5px solid #000;
            border-radius: 4px;
        }

        *{
    margin: 0;
    padding: 0;
    box-sizing:border-box;
    font-family: 'Poppins', sans-serif;
}
::placeholder{
  color: #000;
}
body{
    display: flex;
    justify-content:center;
    align-items: center;
    min-height: 100vh;
    background-size: cover;
    background-position: center;
    padding: 20px;
    /* background-image: url(./backdoc3.png); */
    /* position: fixed; */
}

h3{
    font-size: 20px;
}
</style>

<section class="appointment" id="appointment">
    <h1 class="heading">Book An Appointment </h1><br><br>
    <div class="row" align="center">
        <form action="" method="post">
          <!-- <h3>Make Appointment</h3>  --><br><br>
            <div class="input-box">  
              <input type="text" name="name" placeholder="Patient Name" class="box">
            </div>
            <div class="input-box">
              <input type="number" name="mobile" placeholder="Phone Number" class="box">
            </div>
            <div class="input-box">
              <input type="email" name="email" placeholder="Email" class="box">
            </div>
            <div class="input-box">
              <input type="date" name="date" class="box">
            </div>
              <select id="doctor" name="profession" required aria-placeholder="menu">
                <option value=""></option>
                <option value="Interventional cardiologist">Interventional cardiologist</option>
                <option value="Cardiac imaging specialist">Cardiac imaging specialist</option>
                <option value="Electrophysiologists">Electrophysiologists</option>
                <option value="General adult cardiologist">General adult cardiologist</option>
                <option value="Heart failure specialist">Heart failure specialist</option>
              </select>
              <div class="sub">
                <input type="submit" name="submit" value="Appointment Now" class="btn">
              </div>  
        </form>
   </div>
</section>
  </body>
</html>
<?php
$con = mysqli_connect("localhost","root","");
$db = mysqli_select_db($con,"dbms");

if(isset($_POST['submit']))
{
  $name = $_POST['name'];
  $email = $_POST['email'];
  $mobile = $_POST['mobile'];
  $date = $_POST['date'];
  $profession = $_POST['profession'];
  $query = "INSERT INTO bookappoint (name,email,mobile,date,profession) VALUES ('$name','$email','$mobile','$date','$profession')";
  $query_run = mysqli_query($con,$query);
  if($query_run)
  { 
    echo '<script  type="text/javascript"> alter("Data Saved")</script>';
  }
  else{
    
    echo '<script  type="text/javascript"> alter("Data Not Saved")</script>';
 
  }
}
?>