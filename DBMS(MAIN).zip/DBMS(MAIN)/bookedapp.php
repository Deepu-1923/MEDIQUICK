<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Booked</title>
</head>
<body>
    <h1>Appointment Booked on <?php echo $date ?></h1>
    <?php  echo $name ?>
    <h2>Please Visit Our Hospital On That Date</h2>
</body>
</html>