<?php 
  $con = mysqli_connect('localhost','root','','dbms') or die("Couldn't connect");
?>