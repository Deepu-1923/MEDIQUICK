<?php
    $servername="localhost";
    $username="root";
    $password="root";
    $db_name="testdd";
    $con=new mysqli($servername,$username,$password,$db_name,3306);
    if($conn->connect_error){
        die("connect failed".$conn->connect_error);
    }
echo "";
?>
if(empty($_POST["name"])){
    die("Name is required");
}
if(! filter_var($_POST["email"],FILTER_VALIDATE_EMAIL)){
    die("valid email is required");
}
    print_r($_POST);
if(strlen($_POST["password"]<8)){
    die("Password must be least 8 characters");
}
if(! preg_match("/[a-z]/i",$_POST["password"])){
    die("password must contain at least one letter");
}
if(! preg_match("/[0-9]/i",$_POST["password"])){
    die("password must contain at least one number");
}
print_r($_POST);