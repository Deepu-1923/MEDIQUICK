<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" sizes="any" mask="" href="./stethoscope-solid.svg" style="color: #1c5fd4;">
    <link rel="stylesheet" href="./siri.css">
    <title>Cardiologist Consultation</title>
    <style>
        
/* login */
.wrapper{
    width: 600px;
    background:transparent;
    backdrop-filter: blur(5px);
    color: whitesmoke;
    border-radius: 35px;
    padding: 30px 40px;
    box-shadow: 0 0 15px black;
}

.wrapper h1{
    font-size: 36px;
    text-align: center;
}

.wrapper .input-box{
    position: relative;
    width: 100%;
    height: 50px;
    margin: 30px 0;
    /* box-shadow: 0 0 15px black; */
    border-radius: 35px ;
}

.input-box input{
    width: 100%;
    height: 100%;
    background: transparent;
    border: none;
    outline: none;
    border: 2px solid black;
    border-radius: 40px;
    font-size:16px;
    color:black;
    padding: 20px 30px 5px 20px;
}

.input-box span{
    position:absolute;
    left: 0;
    padding:15px 20px;
    pointer-events: none;
    font-size: 1rem;
    transition: 0.5s;
    text-transform: uppercase;
    color:black;
    letter-spacing: 0.1em;
}
.input-box input:focus~span,
.input-box input:valid~span
{
    color: black;
    font-size: 0.75em;
    transform: translateX(20px) translateY(-7px);
    padding: 0 5px;
    background: transparent;
    border-radius: 2px;
    backdrop-filter: blur(10px);

}
        body {
            font-family: 'Arial', sans-serif;
            margin: 0;
            padding: 0;
            background-image: url(./backdoc3.jpg);
        }
        /* section {
            max-width: 800px;
            margin: 2em auto;
            padding: 1em;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        } */

        form {
            display: grid;
            gap: 1em;
        }

        label {
            font-weight: bold;
            display: block;
            margin-bottom: 0.5em;
        }

        input,
        select,
        textarea {
            width: 100%;
            padding: 0.5em;
            margin-top: 0.5em;
            box-sizing: border-box;
            border: 1px solid #000;
            border-radius: 4px;
            background: transparent;
        }

        textarea {
            resize: vertical;
        }

        button {
            background-color: #000;
            color: #fff;
            padding: 0.5em 1em;
            border: none;
            cursor: pointer;
            border-radius: 25px;
        }

        button:hover {
            background-color: #555;
        }
        h1{
            text-align: center;
        }
        ::placeholder{
            color: #000;
            text-align: center;
        }
    </style>
</head>
<body>
<section>
    <div class="wrapper">
    <h1>Consultation</h1>
        <form action="#" method="post">
            <input type="text" id="name" name="name" placeholder="Name" required>
            <input type="email" id="email" name="email" placeholder="email" required>
             <input type="number" id="phone" name="phone" placeholder="phone" required>
            <label for="doctor" style="color:#000;">Choose a Doctor:</label>
            <select id="doctor" name="doctor" required>
                <option value="dr-siri"></option>
                <option value="Dr Mohan Rao">Dr Mohan Rao</option>
                <option value="Dr Rajesh Kumar Reddy">Dr Rajesh Kumar Reddy</option>
                <option value="Dr Shushmitha">Dr Shushmitha</option>
                <option value="Dr Chanti Reddy">Dr Chanti Reddy</option>
            </select>
            <label for="doctor" style="color:#000;">Choose Doctor's profession:</label>
            <select id="doctor" name="profession" required >
                <option value="dr-siri"></option>
                <option value="dr-siri">Interventional cardiologist</option>
                <option value="dr-siri">Cardiac imaging specialist</option>
                <option value="dr-deepthi">Electrophysiologists</option>
                <option value="dr-prasad">General adult cardiologist</option>
                <option value="dr-prasad">Heart failure specialist</option>
            </select>
            <label for="message" style="color:#000;">Message:</label>
            <textarea id="message" name="message" rows="4" required></textarea>
            <button type="submit">Schedule Consultation</button>
        </form>
    </div>    
</section>
</body>
</html>