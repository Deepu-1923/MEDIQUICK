<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" sizes="any" mask="" href="./stethoscope-solid.svg" style="color: #1c5fd4;">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="siri.css">
    <style>
        body {
             font-family: Arial, sans-serif; 
             background: url(https://i0.wp.com/backgroundabstract.com/wp-content/uploads/edd/2022/06/soft_blue_mosaic_pattern_background-e1655909204819.jpg?resize=1000%2C750&ssl=1);
             margin: 0;
             padding-top: 6%;
             display: flex;
             align-items: center;
             justify-content: center;
             height: 100vh;
             width: 100%;
        }

        .container{
            background:transparent;
            border-radius: 35px;
            width: 450px;
            height: 80%;
            text-align: center;
            color: #000;
            box-shadow: #01ca8b;
        }
    .forgot-container a button {
    display: inline-block;
    text-transform: capitalize;
    font-size:20px ;
    font-weight: 900;
    color: #fff;
    padding:10px 50px;
    border-radius: 2px;
    position: relative;
    border:1px solid #01ca8b;
    box-shadow: 0 0 0 4em #01ca8b inset;
    transition: all 350ms ease;
   }
        input {
            width: 100%;
            height: 30px;
            padding: 25px;
            margin-bottom: 15px;
            box-sizing: border-box;
            border-radius: 30px;
            border-color:#000;
            background:transparent;
        }

        button {
            background-color: #01ca8b;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        button:hover {
            background-color: #01ca8b;
        }
        .forgot-container p{
            font-size: 20px;
        }
        .forgot-container h2{
            display: flex;
            font-size: 60px;
            font-weight: 80px;
        }
        .forgot-container span{
            display: flex;
            font-size: 60px;
            font-weight: 80px;
            color: #fff;
            gap: 2px;
        }
        ::placeholder{
            color: #000;
            font-size: 16px;
        }
         
.sub{
    width: 100%;
    height: 45px;
    background: black;
    border: none;
    outline: none;
    border-radius: 40px;
    box-shadow: 0 3px 10px #fff;
    cursor: pointer;
    font-size: 16px;
    color: #fff;
    font-weight:600;
    position: relative;
}
.sub a p{
  color: #fff;
  text-align:center;
  text-decoration:none;
}
h2{
    text-align: center;
    font-size: 45px;
    color: #000;
}
h2 span{
    font-size: 45px;
    color: #fff;
}
p{
    text-align: center;
    color: #000;
    font-size: 20px;
}
.sub a p{
    text-align: center;
    color: #fff;
    text-decoration: none;
    font-size: 20px;
    padding-top: 8px;
}
</style>
</head>
<body>
    <div class="container">
        <h2>Forgot <span>  Password</span></h2><br>
        <p>Enter your email address to reset your password.</p>
        <br>
        <form action="forgot_password.php" method="post">
            <input type="email" name="email" placeholder="Please Enter Your Email..." required>
        <div class="sub">
            <a href="./verification.html"><p>Submit</p></a>
        </div>
        </form>
    </div>
</body>
</html>
