<?php 
//    session_start();

   include("configure.php");
   if(!isset($_SESSION['valid']))
   {
        include("userlogin.php");
   }
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="siri.css">
    <title>Home</title>
</head>
<style>
.container{
    position: relative;
    max-width: 790px;
    width: 100%;
    background: transparent; 
    backdrop-filter: blur(5px);
    padding: 25px;
    border-radius: 45px;
    box-shadow: 0 0 15px #000;
    padding-left: 1px;
    padding-right: 1px;
    /* box-shadow: black; */
    color: #000;
}

.sub {
    align-items: center;
    width: 100%;
    height: 45px;
    background: black;
    border: none;
    outline: none;
    border-radius: 40px;
    box-shadow: 0 0 10px #fff;
    cursor: pointer;
    font-size: 16px;
    color: #fff;
    font-weight:600;
    position: relative;
}
.box p{
    align-items: center;
    text-align: center;
}
</style>
<body>
    <div class="nav">
        <!-- <div class="logo">
            <p><a href="home.php">Logo</a> </p>
        </div> -->

        <div class="right-links">

            <?php 
            
            $id = $_SESSION['id'];
            $query = mysqli_query($con,"SELECT * FROM users WHERE id=$id");

            while($result = mysqli_fetch_assoc($query)){
                $res_Uname = $result['name'];
                $res_Email = $result['email'];
                $res_Age = $result['age'];
                $res_id = $result['id'];
            }
            
            ?>
        </div>
    </div>
    <main>
    <div class="container">
        <div class="main-box top">
            <!-- <div class="top">
                <div class="box">
                    <p>   Hello<?php echo $res_Uname ?><b>, Welcome</b>
                </div><br>
                <div class="box">
                    <p> Your Email is : <b><?php echo "\n" ;echo $res_Email ?></b>.</p>
                </div>
            </div>
            <div class="bottom">
                <div class="box">
                    <p>     And you are <b><?php echo $res_Age ?></b> years old.</p> 
                </div>
            </div> -->
            <div class="box">
                <p>Welcome, <b><?php echo $res_Uname ?></b></p>
            </div>
        </div>
        <br>
        <div class="sub">
            <a href="mini_proj.php"> <button class="btn">Go to home</button> </a>
        </div>
    </div>    
    </main>
</body>
</html>