<?php 
   session_start();

   include("configure.php");
   if(!isset($_SESSION['valid'])){
    include("userlogin.php");
   }
?>
<?php
       echo "<a href='edit.php? id=$res_id'>Change Profile</a>";
       ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style/style.css">
    <title>Home</title>
</head>
<body>
    <div class="nav">
        <div class="logo">
            <p><a href="home.php">Logo</a> </p>
        </div>

        <div class="right-links">

            <?php 
            
            $id = $_SESSION['id'];
            $query = mysqli_query($con,"SELECT*FROM users WHERE id=$id");

            while($result = mysqli_fetch_assoc($query)){
                $res_Uname = $result['name'];
                $res_Email = $result['email'];
                $res_Age = $result['age'];
                $res_id = $result['id'];
            }
            
            echo "<a href='edit.php?Id=$res_id'>Change Profile</a>";
            ?>

            <a href="php/logout.php"> <button class="btn">Log Out</button> </a>

        </div>
    </div>
    <main>

       <div class="main-box top">
          <div class="top">
            <div class="box">
                <p>Hello <b><?php echo $res_Uname ?></b>, Welcome</p>
            </div>
            <div class="box">
                <p>Your email is <b><?php echo $res_Email ?></b>.</p>
            </div>
          </div>
          <div class="bottom">
            <div class="box">
                <p>And you are <b><?php echo $res_Age ?> years old</b>.</p> 
            </div>
          </div>
       </div>

    </main>
</body>
</html>








<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="siri.css">
    <title>Register</title>
</head>
<body>
      <div class="container">
        <div class="box form-box">

        <?php 
         
         include("configure.php");
         if(isset($_POST['submit'])){
            $id=$POST['id'];
            $name = $_POST['name'];
            $email = $_POST['email'];
            $age = $_POST['age'];
            $password = $_POST['password'];
            $gender = $_POST['gender'];
         //verifying the unique email

         $verify_query = mysqli_query($con,"SELECT email FROM users WHERE email='$email'");

         if(mysqli_num_rows($verify_query) !=0 ){
            echo "<div class='message'>
                      <p>This email is used, Try another One Please!</p>
                  </div> <br>";
            echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button>";
         }
         else{

            mysqli_query($con,"INSERT INTO users(id,name,email,age,password,gender) VALUES('$id',$name','$email','$age','$password','$gender')") or die("Erros Occured");

            echo "<div class='message'>
                      <p>Registration successfully!</p>
                  </div> <br>";
            echo "<a href='userlogin.php'><button class='btn'>Login Now</button>";
         

         }

         }else{
         
        ?>

            <header>Register Now</header>
            <form action="#" class="form">
            <div class="inputbox">
                <input type="text" required/>
                <span>Full Name</span>
            </div>
            
               <div class="gender-box">
                    <div class="inputbox">
                        <input type="text" id="check-female" name="gender" placeholder="Male/Female/Others.."/>
                    </div>
                </div>

            <div class="inputbox">
                <input type="text" required />
                <span>Email Address</span>
            </div>

            <div class="column">
                <div class="inputbox">
                    <input type="number" id="number" required/>
                    <span>Phone number</span>
                </div>
                <div class="inputbox">
                    <input type="date" required/>
                </div>
            </div>
            <!-- <div class="column">
                <div class="inputbox">
                    <input type="password" id="password"required/>
                    <span>PASSWORD</span>
                </div>
            </div> -->

            <div class="column">
                <div class="inputbox">
                    <input type="password" id="password" required> 
                        <!-- <img src="./eye-solid (1).svg"/> -->
                        <span>Password</span>
                          <!-- <img src="./eye-solid (1).svg"/>  -->
                    </input>
                </div>
            </div>  
            <div class="sub"> 
                    <input type="submit" class="btn" name="submit" value="Register" required>
            </div>
            <div class="links">
                    Already a member? <a href="userlogin.php">Sign In</a>
            </div>
        </form>    
        </div>
        <?php } ?>
      </div>

</body>
</html>









<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="siri.css">
    <title>Register</title>
</head>
<body>
      <div class="container">
        <div class="box form-box">

        <?php 
         
         include("configure.php");
         if(isset($_POST['submit'])){
            $name = $_POST['name'];
            $email = $_POST['email'];
            $age = $_POST['age'];
            $password = $_POST['password'];

         //verifying the unique email

         $verify_query = mysqli_query($con,"SELECT email FROM users WHERE email='$email'");

         if(mysqli_num_rows($verify_query) !=0 ){
            echo "<div class='message'>
                      <p>This email is used, Try another One Please!</p>
                  </div> <br>";
            echo "<a href='javascript:self.history.back()'><button class='btn'>Go Back</button>";
         }
         else{

            mysqli_query($con,"INSERT INTO users(name,email,age,password) VALUES('$name','$email','$age','$password')") or die("Erros Occured");

            echo "<div class='message'>
                      <p>Registration successfully!</p>
                  </div> <br>";
            echo "<a href='userlogin.php'><button class='btn'>Login Now</button>";
         

         }

         }else{
         
        ?>
        <div class="container1">
            <header>REGISTER NOW</header>
            <form action="" method="post">
                <div class="input-box">
                    <input type="text" name="username" id="username" placeholder="Username" autocomplete="off" required>
                </div>
                <br>
                <div class="input-box">
                    <input type="text" name="state" id="state" placeholder="State" autocomplete="off" required>
                </div>
                <br>
                <div class="input-box">
                    <input type="text" name="email" id="email" placeholder="Email" autocomplete="off" required>
                </div><br>
                <div class="gender-box">
                    <div class="input-box">
                        <input type="text" name="gender"  id="gender" placeholder="Male/Female/Others.." autocomplete="off" required>
                    </div>
                </div><br>
                <div class="column">
                <div class="inputbox">
                    <input type="number" id="number" required/>
                    <span>Phone number</span>
                </div>
                <div class="inputbox">
                    <input type="date" required/>
                </div>
                </div>

                <div class="input-box">
                    <input type="number" name="age" id="age" placeholder="Age" autocomplete="off" required>
                </div><br>
                <div class="input-box">
                    <input type="password" name="password" id="password" placeholder="Password" autocomplete="off" required>
                </div>
                <br>
                <div class="sub">
                    <input type="submit" class="btn" name="submit" value="Register" required>
                </div>
                <!-- <div class="links">
                    Already a member? <a href="userlogin.php">Sign In</a>
                </div> -->
            </form>
        </div>
        <?php } ?>
      </div>
      </div>
</body>
</html>