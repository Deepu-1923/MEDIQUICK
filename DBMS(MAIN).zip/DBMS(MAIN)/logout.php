<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logout</title>
</head>
<style>
.sub {
    width: 100%;
    height: 45px;
    background: black;
    border: none;
    outline: none;
    border-radius: 40px;
    box-shadow: 0 0 10px #fff;
    cursor: pointer;
    font-size: 16px;
    color: #fff;
    font-weight:600;
    position: relative;
}
</style>
<body>
<?php
    echo    "<div class='container'
                <a href='mini_proj.php'><button class='sub'>LogOut</button>
            </div>";
    echo    "<script>
               alert('You Logged Out');
            </script>";  

?> 
</body>
</html>