<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" sizes="any" mask="" href="./stethoscope-solid.svg" style="color: #1c5fd4;">
    <title>MediQuick</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://fontawesome.com/search?q=super%20mario&o=r" integrity="sha384-CDkofqMo6hSAPRh2TZj9HOLusb5hze4z6vkh6YWvd810w+KTuT5lucK9hQN36Xh7" crossorigin="anonymous"/>
    <link rel="stylesheet" href="join2.css">
</head>
<style>
.banner{
    padding: 0;
    margin: 0;
}
a,a:hover{
    text-decoration: none;
}
.mt-20px{
    margin-top:20px;
}
.md-20px{
    margin-top: 20px;
    margin-right: 2px;
}
.border{
    border-right: 1px solid rgb(255 255 255/0.4);
}
.col-md-7{
    width:40%;
}
.col-md-2{
    padding-top: 2px;
}
.btn-green{
    display:inline-block;
    text-transform: capitalize;
    font-size:16px ;
    font-weight: 900;
    color: #000;
    padding:10px 50px;
    border-radius: 2px;
    position: relative;
    border:1px solid #01ca8b;
    box-shadow: 0 0 0 4em #01ca8b inset;
    transition: all 350ms ease;
}
.user-logo{
    display:inline-block;
    text-transform: capitalize;
    font-size:16px;
    font-weight: 900;
    color: #000;
    border-radius: 2px;
    padding: 8px 20px;
    position: relative;
    border:1px solid #01ca8b;
    box-shadow: 0 0 0 4em #01ca8b inset;
    transition: all 350ms ease;
}
.btn-green img{
    margin-right:18px;
    margin-left: -25px;
    padding-left: 3px;
    color: #fff;
}
.user-logo a img{
    margin-right:10px;
    margin-left: 3px;
    padding-left: 3px;
    padding-top: 3px;
    padding-bottom: 5px;
    color: #000;
}   
.user-logo a{
    color: #000;
}
.btn-green:hover{
    box-shadow: 0 0 0 0 #01ca8b inset;
    background: #fff;
    color: #000;
}
.user-logo:hover{
    box-shadow: 0 0 0 0 #01ca8b inset;
    background: #fff;
    color: #01ca8b;
}
.btn-transparent{
    border:1px solid #fff;
}
/*.user-logo-transparent{
    border:1px solid #fff;
}*/
header{
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
    width: 100%;
    height: 15%;
    border-bottom:1px solid #fff ;
    /*background: #000;*/
}
.header-active{
    position: fixed;
    background: #000;
    z-index:1;
    top:0;
    animation-name: example;
    animation-duration: 0.8s;
}
@keyframes example{
    from{top:-200px;}
    to{top:0;}
}
.logo{
    display:inline-block;
    padding-right: 30px;
}
.menu{
    display:inline-block;
    padding-right: 60px;
    padding-top: 0px;
}
.menu ul{
    padding: 0;
    margin: 0;
}
.menu ul li{
    display: inline-block;
    list-style-type: none;
    margin: 0 20px;
    padding-top: 20px;
    color: #fff;
}
.menu ul li a{
    color:#fff;
    text-transform: capitalize;
    font-weight: 900;
    font-size: 18px;
    letter-spacing: 1px;
    position: relative;
}
.menu ul li a::before{
    content: '';
    position: absolute;
    background-color: #fff;
    width: 0;
    height: 2px;
    bottom: -5px;
    left:0; 
    transition: 0.2s ease-in-out;
}
.menu ul li a:hover::before{
    width:100%;
}
.header-social{
    margin-top: 3px;
}
.header-social ul{
    margin: 0;
    padding:0;
}
.header-social ul li{
    list-style-type: none;
    /*display: inline-block;*/
    display: flex;
    flex-direction: row;
    margin: 0 10px;
}
.header-social ul li a{
     color: #fff;
     font-size: small;
     font-weight: 1000;
     padding-top: 10px;
     /*background: rgb(255 255 255/0.22);
     width: 41px;
     height: 41px;
     border-radius: 50%;
     display: inline-block;
     position: relative;*/
}
.header-social ul li a img{
    position: absolute; 
    transform:translate(-50%,-50%);
    display: inline-block;
    font-size: 30px;
    transition: 0.2s ease-in-out;
    padding-top: 20px;
    padding-left: 0px;
    padding-right: 40px;
}
.header-social ul li a:hover img{
    color:#01ca8b;
}




/*banner*/
.banner{
    background-position: 50% 0;
    background-size: cover;
    background-repeat: no-repeat;
    padding: 16em 0 14em 0;
    box-shadow: -5px -5px 30px 5px #e1f3ff 5px 5px 30px 5px #e1f3ff;
}
.banner-content{
    width: 80%;
}
.banner-content h1{
    color:#01ca8b;
    font-size:80px;
    font-weight: 800;
    margin-top: 10px;
    line-height: 80px;
}
.service{
    border-radius: 10px;
    background: #ffffff45;
    border:1px solid #dfdfdf94;
    margin-top: 20%;
    margin-bottom: 5%;
    height: 10%;
}
.service a{
    display: inline-block;
    width: 33%;
    color: #000;
    font-size: 20px;
    font-weight:800;
    border-right: 1px solid #fff;
    padding: 34px 20px;
    margin: 0 -2px;
    height: 220px;
    vertical-align: top;
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
}
.service a:last-child
{
    border-right:none;
    background-image: url(./backdoc3.png);
    background-size:cover;
    background-repeat: no-repeat;
    background-position: center;
    border-top-right-radius: 10px;
    border-bottom-right-radius: 10px;
    border-top-left-radius:0px;
    border-bottom-left-radius: 0px;
    width: 34.2%;
}
.service-content{
    width: calc(100% - 47px);
    display: inline-block;
    vertical-align: middle;
    position:relative;
}
.service-content::before{
    content:'';
    position: absolute;
    left:0;
    bottom:-5px;
    background: #000;
    height: 2px;
    width: 0;
    transition: 0.2s ease-in-out;
}
.service a:hover .service-content::before{
    width: 50%;
}
.service-btn{
    width: 40px;
    display: inline-block;
    height: 40px;
    background: #ffffff45;
    border-radius:50%;
    position: relative;
    vertical-align: middle;
}
.service-btn img{
    position: absolute;
    top:50%;
    left:50%;
    transform: translate(-50%,-50%);
    transition: 0.2s ease-in-out;
}
.service a:hover .service-btn img{
    transform: rotate(-40deg);
    top:26%;
    left:32%;
}
.service-icon{
    font-size: 20px;
    margin-top:22px ;
}
.call{
    display:inline-block;
    width: 40px;
    vertical-align: middle;
}
.call-number{
    width:calc(100% - 54px);
    display: inline-block;
    vertical-align: middle;
}
.call-number p{
    font-size: 14px;
    text-transform:uppercase;
}
.call-number h3{
    margin: 0;
    font-weight: 600;
    letter-spacing: 1px;
}
/*work*/
.work{
    position:relative;
    margin-top:-80px;
    
}
.hours{
    background: #01ca8b;
    border-radius: 10px;
    padding: 40px 50px;
}
.hours h2{
    color:#fff;
    font-weight:900;
    margin: 0 0 30px;
}
.time{
    border-top: 1px solid rgb(255 255 255/0.52);
    padding: 30px 0;
}
.time:last-child{
    padding-bottom: 0;
}
.time h4, .time p{
    text-align: left;
    color:#fff;
    font-weight: 600;
}
.booking{
    display: inline-block;
    width: 80px;
    margin-left: -4px;
    color: #fff;
    font-weight: 600;
    font-size:15px;
}
.btn-white{
    background: #fff;
    color:#01ca8b;
    border:none;
    outline: none;
    border-radius: 2px;
    padding: 4px 5px;
}
.btn-white img{
    margin-right: 4px;
}
.response{
    border-radius: 10px;
    border:1px solid #ebebeb;
    overflow: hidden;
}
.response-bg{
    height: 260px;
    background-position: center;
    background-size: cover;
    background-repeat: no-repeat;
    border-top-left-radius: 10px;
    border-bottom-left-radius: 10px;
    transition: 0.4s ease-in-out;
}
.response a:hover .response-bg{
    transform: scale(1.04);
}
.response-content{
    padding: 90px 30px 30px;
    text-align: left;
    clip-path: polygon(0 0,100% 20%,100% 100%,0% 100%);
    background: #fff;
    position: relative;
    margin-top: -70px;
}
.response-icon{
    background: #000;
    border-radius: 2px;
    width: 70px;
    height: 70px;
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
}
.response-icon img{
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    color: #fff;
    font-size: 30px;
}
.response-content h2{
     color: #000;
     font-weight: 600;
     line-height: 36px;
}
.response-content p{
    color: #8b8b8b;
    font-size:15px;
    margin:24px 0 0;
}
.read-more{
    border:none;
    outline: none;
    background: transparent;
    color: #01ca8b;
    text-transform: uppercase;
    font-weight:600;
    transition: 0.2s ease-in-out;
}
.read-more img{
    margin-left:4px;
    transition: 0.2s ease-in-out;
}
.response a:hover .read-more{
    color: #000;
}
.response a:hover .read-more img{
    color:#01ca8b;
    margin-left: 6px;
}

.menu ul li a{
    font-size: 25px;
    font-weight: 100;
    color: #fff;
}
</style>
<header>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-7 border">
                <div class="logo_border">
                    <!-- <a href="mini_proj.php"> -->
                        <img src="./heart-pulse-solid (4).svg" alt="Logo" align="left" style="height:70px;width:70px;padding-top:20px;">
                    <!-- </a> -->
                </div>
                <div class="menu">
                    <ul>
                        <li>
                            <a href="./mini_proj.php">Home</a>
                        </li>
                        <li>
                            <a href="./about.php">About</a>
                        </li>
                        <li>
                            <a href="./consult.php">Consult</a>
                        </li>
                        <!---<li>
                            <a href="javascript:void(0);">Help</a>
                        </li>--->
                    </ul>
                </div>
            </div> 
            <div class="col-md-2 border">
                <div class="header-social text-center">
                    <ul>
                        <li>
                            <a href="javascript:void(0);">
                                <img src="./phone-solid.svg" style="padding-right: 30px; padding-top:15px;">Contact Us<br>+91 9849498527 
                            </a>
                        </li>
                        <!---<li>
                            <a href="javascript:void(0);">
                               <img src="./truck-medical-solid.svg">Ambulance<br>
                            </a>
                        </li>--->
                        <!-- <li>
                            <a href="./medicines.php">
                               <img src="./pills-solid.svg"  style="padding-right: 30px;">       Medicine
                            </a>
                        </li> -->
                    </ul>    
                </div>
            </div>
            <div class="col-md-3">
                <a href="./please-login.php" class="btn-green mt-20px">
                    <img src="./calendar-check-solid.svg" style="padding-left: 0px;">Make a Payment
                </a>
            </div> 
            <div class="user-logo md-20px">
                <a href="login.php">
                    <img src="./user-solid (2).svg" style="margin-bottom:2px;">Login
                </a>
            </div>
        </div>
    </div>                   
</header>
<section class="banner" style="background-image: url(./backdoc7.jpg);">
    <div class="container">
        <div class="banner-content">
           <!---- <img src="./heart-pulse-solid (4).svg" alt="Banner-Logo">--->
            <h1>Our experience at your service</h1>
        </div>
        <div class="service">
            <a href="./please-login.php">
                <div class="service-content">
                    Our Service
                </div>
                <div class="service-btn">
                    <img src="./arrow-right-solid (2).svg" style="height:20px">
                </div>
                <div class="service-icon">
                    <img src="./heart-pulse-solid (6).svg" style="height: 25px;">
                </div>
            </a>
            <a href="./please-login.php">
                <div class="service-content">
                    Book an Appointment
                </div>
                <div class="service-btn">
                    <img src="./arrow-right-solid (2).svg" style="height:20px">
                </div>
                <div class="service-icon">
                    <img src="./calendar-check-solid.svg" style="height: 20px;">
                </div>
            </a>
            <a href="javascript:void(0);">
                <div class="service-content">
                   Have an Emergency?
                </div>
                <div class="service-btn">
                    <img src="./arrow-right-solid (2).svg" style="height:20px">
                </div>
                <div class="service-icon">
                    <div class="call">
                         <img src="./phone-solid (1).svg" style="height: 20px;">
                    </div>
                    <div class="call-number">
                        <p>Emergengy Line</p>
                        <h3>+91 9849498527</h3>
                    </div>
                </div>
            </a>
        </div>
    </div>
</section>
<section class="work">
    <div class="container-fluid text-center">
        <div class="row">
            <div class="col-md-4">
                <div class="hours">
                    <h2>Working Hours</h2>
                    <div class="time">
                        <div class="booking">Monday</div>
                        <div class="booking">7AM-10PM</div>
                        <div class="booking">
                            <a href="./please-login.php">
                               <button type="button" class="btn-white">
                                   <img src="./calendar-regular.svg">Book
                               </button>
                            </a>
                        </div>
                    </div>
                    <div class="time">
                        <div class="booking">Tuesday</div>
                        <div class="booking">7AM-10PM</div>
                        <div class="booking">
                            <a href="./please-login.php">
                                <button type="button" class="btn-white">
                                    <img src="./calendar-regular.svg">Book
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="time">
                        <div class="booking">Wednes
                            day</div>
                        <div class="booking"> 7AM-10PM</div>
                        <div class="booking">
                            <a href="./please-login.php">
                                <button type="button" class="btn-white">
                                    <img src="./calendar-regular.svg">Book
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="time">
                        <div class="booking">Friday</div>
                        <div class="booking">7AM-10PM</div>
                        <div class="booking">
                            <a href="./please-login.php">
                                <button type="button" class="btn-white">
                                    <img src="./calendar-regular.svg">Book
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="time">
                        <div class="booking">Saturday</div>
                        <div class="booking">7AM-10PM</div>
                        <div class="booking">
                            <a href="./please-login.php">
                                <button type="button" class="btn-white">
                                    <img src="./calendar-regular.svg">Book
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="time">
                        <div class="booking">Sunday</div>
                        <div class="booking">7AM-10PM</div>
                        <div class="booking">
                            <a href="./please-login.php">
                                <button type="button" class="btn-white">
                                    <img src="./calendar-regular.svg">Book
                                </button>
                            </a>
                        </div>
                    </div>
                    <div class="time">
                        <h4>Time not Flexible ?</h4>
                        <a href="./please-login.php">
                        <button type="button" class="btn-green btn-tranparent mt-20px">
                            <img src="./calendar-check-solid.svg">Suggest Checkup Time
                        </button> 
                        </a>   
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="response">
                    <a href="./please-login.php">
                        <div class="response-bg" style="background-image: url(./beds.jpeg);"></div>
                        <div class="response-content">
                            <div class="response-icon">
                                <img src="./book-medical-solid.svg">
                            </div>
                            <h2>Doctor's Dairy</h2>
                            <p>A gentle guide for everyone in pursuit of good health in essence, a doctor's diary reflecting health, healing and hope.</p>
                            <button type="button" class="read-more mt-20px">Read More
                                <img src="./arrow-right-solid (2).svg" style="height:20px">
                            </button>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="response">
                    <a href="./please-login.php">
                        <div class="response-bg" style="background-image: url(./covid.jpg);"></div>
                        <div class="response-content">
                            <div class="response-icon">
                                <img src="./virus-covid-solid.svg">
                            </div>
                            <h2>Covid-19 Response</h2>
                            <p>Doctors who sacrificed their life while saving patients during the ongoing COVID-19 pandemic.We respect every life.</p>
                            <button type="button" class="read-more mt-20px">Read More
                                <img src="./arrow-right-solid (2).svg" style="height:20px">
                            </button>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="response">
                    <a href="./please-login.php">
                        <div class="response-bg" style="background-image: url(./ambulance.webp);"></div>
                        <div class="response-content">
                            <div class="response-icon">
                                <img src="./truck-medical-solid.svg">
                            </div>
                            <h2>Book Ambulance</h2>
                            <p>For every care or life-changing care  makes us smile.Book quick slot for ambulance.</p><br>
                            <button type="button" class="read-more mt-20px">Read More
                                <img src="./arrow-right-solid (2).svg" style="height:20px">
                            </button>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="response">
                    <a href="./please-login.php">
                        <div class="response-bg" style="background-image: url(./images/medi.png);"></div>
                        <div class="response-content">
                            <div class="response-icon">
                                <img src="./pills-solid.svg">
                            </div>
                            <h2>Medicines</h2>
                            <p>We have the best doctors surgeons and specialists with over 20 years of experience.<p>
                            <button type="button" class="read-more mt-20px">Read More
                                <img src="./arrow-right-solid (2).svg" style="height:20px">
                            </button>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>    
</section>
<script>
    var header=document.getElementsByTagName("header");
    window.onscroll=function() {scrollFunction()};
     function scrollFunction(){
        if(document.body.scrollTop>200||document.documentElement.scrollTop>200){
             header[0].setAttribute("class","header-active");
        }
        else{
             header[0].removeAttribute("class")
        }
    }
</script>
</html>