<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" sizes="any" mask="" href="./stethoscope-solid.svg" style="color: #1c5fd4;">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Please Login</title>
    <style>
        body h1{
              color: #000;
              font-size: 100px;
              text-align: center;
        }
        span{
            color: rgb(95,222, 156);
        }
        h2{
            color: #000;
            font-size: 40px;text-align: center;
        }
        .decor a{
            text-decoration: none;
            align-items: center;
            color: blue;
            font-size: 25px;
            text-align: center;

        }
        h4{
            text-align: center;
            font-size: 20px;
        
        }
    </style>
</head>
<body>
    <h1>Medi<span>Quick</span></h1>
    <h2>Please Login Or Resister to visit our webiste...</h2>
    <div class="decor"> 
        <h4>___click below___</h4>   
        <a href="./login.php">
           <h3>>>>> Go to Login Page >>>></h3>
        </a>
    </div>    
</body>
</html>