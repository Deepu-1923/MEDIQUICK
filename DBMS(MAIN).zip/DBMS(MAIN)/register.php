<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" sizes="any" mask="" href="./stethoscope-solid.svg" style="color: #1c5fd4;">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="siri.css">
    <title>Register</title>
    <style>
        .bd{
            height: fit-content;
            background: url(https://i0.wp.com/backgroundabstract.com/wp-content/uploads/edd/2022/06/soft_blue_mosaic_pattern_background-e1655909204819.jpg?resize=1000%2C750&ssl=1);
        }
        .links a{
            margin-bottom: 15px;
            color: black;
            text-align: center;
        }

.sub {
    width: 100%;
    height: 55px;
    background: black;
    border: none;
    outline: none;
    border-radius: 40px;
    box-shadow: 0 0 10px #fff;
    cursor: pointer;
    font-size: 16px;
    color: #fff;
    font-weight:600;
    position: relative;
}
.links{
    text-align: center;
}
.container{
    width: 50%;
    box-shadow: 0 0 10px #000;
}
.column{
    display: flex;
    column-gap: 15px;
    background: transparent;

}
.input-box{
    height: 30px;
}
header{
    font-size: 20px;
}
</style>
</head>
<body class="bd">
    <div class="container">
        <div class="box form-box">

        <?php 
         
         include("configure.php");
         if(isset($_POST['submit']))
         {
            $name = $_POST['name'];
            $email = $_POST['email'];
            $age = $_POST['age'];
            $password = $_POST['password'];
            $mobile = $_POST['mobile'];
            $state = $_POST['state'];
            $country = $_POST['country'];
            $date = $_POST['date'];

         //verifying the unique email

         $verify_query = mysqli_query($con,"SELECT email FROM users WHERE email='$email'");

         if(mysqli_num_rows($verify_query) !=0 ){
            echo '<div>
                      <h1 style="font-size:50px;">This email is used, Try Another One Please!</h1>
                  </div> <br>';
            echo "<div class='sub'>
                    <a href='./userlogin.php'><button class='sub'>Go Back</button>
                  </div>";
         }
         else{

            mysqli_query($con,"INSERT INTO users(name,email,age,password,mobile,state,country,date) VALUES('$name','$email','$age','$password','$mobile','$state','$country','$date')") or die("Erros Occured");

            echo '<div class="sub">
            <script>
                alert("Registration Done!!");
            </script>
                      <h1 style="font-size:50px;"> <Registration successfully done!!</h1><br>
                  </div> <br>';
            echo "<a href='userlogin.php'><button class='sub'>Login Now</button>";
         
        }

        }
        else
        {
         
        ?>
        <header>Registration</header>
            <form action="" method="post">
                <div class="input-box">
                    <!-- <label for="name">name</label> -->
                    <input type="text" name="name" id="name" placeholder="       Enter your Name" autocomplete="off" required>
                </div>
                 <br><br>
                <div class="input-box">
                    <!-- <label for="email">Email</label> -->
                    <input type="text" name="email" id="email" placeholder="     Enter your Email" autocomplete="off" required>
                </div>
                <br><br>
                <div class="column">
                    <div class="input-box">
                        <input type="text" name="state" id="state" placeholder="State" autocomplete="off" required/>
                    </div>
                    <div class="input-box">
                        <input type="text" name="country" id="country" placeholder="Country" autocomplete="off" required/>
                    </div>
                </div>    
                <br><br>
                <div class="column">
                <div class="input-box">
                        <input type="number" name="age" id="age" placeholder="    Enter you Age" autocomplete="off" required>
                    </div>
                    <div class="input-box">
                        <input type="date" name="date" id="date" autocomplete="off" required/>
                    </div>
                </div>
                <br><br>
                <div class="column">
                    <div class="input-box">
                        <input type="password" name="password" id="password" placeholder="      Create New Password" autocomplete="off" required>
                    </div>
                    <div class="input-box">
                        <input type="number" name="mobile" id="mobile" placeholder="      Enter Phone number" autocomplete="off" required/>
                    </div>
                </div>    
                <br><br>
                <div class="sub">
                    <input type="submit" class="btn" name="submit" value="Register" required/>
                <br></div>
                <div class="links">
                    Already a member? <a href="login.php">Sign In</a>
                </div>
            </form>
        </div>
        <?php } ?>
      </div>
</body>
</html>