<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="icon" sizes="any" mask="" href="./stethoscope-solid.svg" style="color: #1c5fd4;">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="./siri1.css"> -->
    <title>Document</title>
</head>
<style>
  .search-box {
  position: relative;
  width: 500px;
  margin: 0 auto;
  background:transparent;
}

#search-input {
  width: 100%;
  padding: 15px 15px;
  border: 1px solid #ccc;
  border-radius: 25px;
  font-size: 16px;
  background:transparent;
}

#search-button {
  position: absolute;
  top: 50%;
  right: 10px;
  transform: translateY(-50%);
  background-color: transparent;
  border: none;
  cursor: pointer;
  fill: #757575;
}

body{
    /* align-items: center; */
    min-height: 100vh;
    background-size: cover;
    background-position: center;
    /* padding: 20px; */
    background-image: url(./backdoc3.png);
    /* position: fixed; */
}
.model th{
   font-size: 30px;
   color: #000;
}
td{
    font-size: 25px;
}
::placeholder{
    color: #000;
}
</style>

<header>
<br><br><br>
<form method="post"> 
    <div class="search-box">
        <input type="text" id="search-input" placeholder = "Enter Patient Name..." name="search">
        <button name="submit" id="search-button">
            <svg viewBox="0 0 24 24" width="24" height="24">
                <path d="M15.5 14h-.79l-.28-.27C15.41 12.59 16 11.11 16 9.5 16 5.91 13.09 3 9.5 3S3 5.91 3 9.5 5.91 16 9.5 16c1.61 0 3.09-.59 4.23-1.57l.27.28v.79l5 4.99L20.49 19l-4.99-5zm-6 0C7.01 14 5 11.99 5 9.5S7.01 5 9.5 5 14 7.01 14 9.5 11.99 14 9.5 14z"></path>
            </svg>
        </button>
    </div>    
</form>
</header>
<br>
<br>
<br>
<body>
<table class="table">
<?php
    include('configure.php');
if(isset($_POST['submit'])) {
        $search=$_POST['search'];
        $sql= ("SELECT * FROM users WHERE id like '%$search%' or name like '%$search%'");
        $result= mysqli_query($con, $sql);
    if($result) {
        if(mysqli_num_rows ($result)>0) 
        {
	        echo '<thead class="model">
	            <tr>
	            <th>Patient ID &emsp;<hr></th>
	            <th>Patient Name &emsp;<hr></th>
	            <th>State &emsp;<hr></th>
	            </tr>
	            </thead>
	        ';
	    while($row=mysqli_fetch_assoc($result)){
	    echo 
        '<tbody>
	    <tr>
	    <td>'.$row ['id'].'</td>
	    <td>'.$row['name'].'</td>
        <td>'.$row['state'].'</td>

	    </tr>
	    </tbody>
	    ';
        }
    } else {
	        echo ' Data not found';
        }
    }

}

?>
</table>
</div>
</body>
<br><br><br><br><br>
<footer>
    <marquee>
        <h1>Medi Quick</h1>
    </marquee>
</footer>
</html>