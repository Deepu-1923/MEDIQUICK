<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" sizes="any" mask="" href="./stethoscope-solid.svg" style="color: #1c5fd4;">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css" integrity="sha512-DTOQO9RWCH3ppGqcWaEA1BIZOC6xxalwEsw9c2QQeAIftl+Vegovlnee1c9QX4TctnWMn13TZye+giMm8e2LwA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="siri.css">
  <style>
    body {
      font-family: Arial, sans-serif;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
      background: url(https://i0.wp.com/backgroundabstract.com/wp-content/uploads/edd/2022/06/soft_blue_mosaic_pattern_background-e1655909204819.jpg?resize=1000%2C750&ssl=1);
    }

    form {
      width: 300px;
      padding: 20px;
      border: 1px solid #ccc;
      border-radius: 5px;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    label {
      display: block;
      margin-bottom: 8px;
    }

    input {
      width: 100%;
      padding: 8px;
      margin-bottom: 16px;
      box-sizing: border-box;
      background-color: transparent;
      background-image: url(./eye-solid\ \(1\).svg);
      background-position:right;
      padding-left: 30;
      background-size: 20px;
      background-repeat: no-repeat;
      border-radius: 40px;

    }
    
.inputbox input{
    width: 100%;
    height: 100%;
    background: transparent;
    /* border: none; */
    outline: none;
    border: 2px solid #000;
    margin-top: auto;
    border-radius: 40px;
    font-size:3px;
    color:black;
    padding: 20px 45px 20px 20px;
    color: #000;
    font-size: 1.5rem;
    font-weight: 500;
    text-align: center;
    padding: 25px;
}
.input .icon {
  position: absolute;
  left: 10px;
  top: 50%;
  transform: translateY(-50%);
  width: 20px;
  height: 20px;
  /* background: url('icon.png') no-repeat center center; */
  background-size: cover;
}
.input-box img{
  width: 35px;
  cursor: pointer;
 }

    button {
      text-align: center;
      background-color:#01ca8b;
      color: #000;
      padding: 10px 15px;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      align-items: center;
    }
    .container header{
    font-size: 1.5rem;
    color: black;
    font-weight: 500;
    text-align: center;
    padding: 25px;
}

.container{
    position: relative;
    max-width: 500px;
    width: 60%;
    background: transparent; 
    backdrop-filter: blur(5px);
    padding: 25px;
    border-radius: 45px;
    box-shadow: 0 3px 15px #000;
    padding-left: 1px;
    padding-right: 1px;
    /* box-shadow: black; */
    color: #000;
}
.container h1{
  text-align: center;
  font-size: 40px;
}
.container span{
  color: #fff;
  font-size: 45px;
}
    button:hover {
      background-color: #01ca8b;
    }
    input::placeholder{
      color: #000;
    }
    
.sub{
    width: 100%;
    height: 45px;
    background: black;
    border: none;
    outline: none;
    border-radius: 40px;
    box-shadow: 0 3px 10px #fff;
    cursor: pointer;
    font-size: 16px;
    color: #fff;
    font-weight:600;
    position: relative;
}
.sub a p{
  color: #fff;
  text-align:center;
  text-decoration:none;
  font-size: 20px;
  padding-top: 8px;
}
  </style>
  <title>Password Form</title>
</head>
<body>
  <div class="container">
    <h1>Create New<span> Password</span></h1><br>
    <!-- <label for="newPassword">New Password:</label> -->
    <input type="password" id="newPassword" name="newPassword" placeholder="New Password" required>
    <!-- <i class="fa-regular fa-eye-slash"></i> -->
    

    <!-- <label for="confirmPassword">Confirm Password:</label> -->
    <input type="password" id="confirmPassword" name="confirmPassword" placeholder="Confirm Password" required>
    <!-- <i class="fa-regular fa-eye-slash"></i> -->
    <script>
      let eyeicon = document.getElementById("eyeicon");
      let password = document.getElementById("password");

      eyeicon.onclick = function()
      {
        if(password.type == "password")
        {
          password.type = "text";
        }
        else{
          password.type = "password";
        }
    }   
    </script>
    <div class="sub">
        <a href="./verification.html"><p>Submit</p></a>
    </div>
  </div>  
</body>
</html>

